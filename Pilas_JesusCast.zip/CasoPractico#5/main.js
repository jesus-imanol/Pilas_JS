/*Caso Práctico #5
Una empresa de reparto de propaganda contrata a sus trabajadores por días. Los datos de los repartidores se almacenan en una lista (número de seguridad social, nombre y total de días trabajados). Se requiere añadir cada trabajador (siempre por el principio), buscar un trabajador por número de seguridad social para calcular total de su sueldo, visualizar la información de los empleados que trabajen exactamente X cantidad de días.
Diseñar una interfaz gráfica que permita al usuario ingresar la información del trabajador, buscar la información de un trabajador en especifico (mostrar el resultado a través de una alerta), visualizar la información de los  trabajadores que cumplan con trabajar X cantidad de dias (mostrar solo los nombres de los trabajadores en una alerta */
let empleados= [{isNS: 344, isNombre: 'Imanol', isDias: 4}]
let empleado;
let precioDia = 300;

function add(){
    let nombre=document.getElementById("nombre").value;
    let numeroSeguridadSocial=document.getElementById("ns").value;
    let diasTrabajados=document.getElementById("noDias").value;
    numeroSeguridadSocial = Number.parseInt(numeroSeguridadSocial);
    diasTrabajados= parseInt(diasTrabajados);
    empleado = {isNS: numeroSeguridadSocial, isNombre: nombre, isDias: diasTrabajados};
    let flag=false;
    for(k=0;k<empleados.length && !flag;k++){
      if(empleados[k].isNS==numeroSeguridadSocial){
        Swal.fire({
          icon: "error",
          title: "Oops...",
          text: "El dato ya existe",
      });
      flag=true;
    }
  }
  if(numeroSeguridadSocial<=0){
    Swal.fire({
      icon: "error",
      title: "Oops...",
      text: "Ingrese positivos",
  });
  }
   else if(flag==false){
  empleados.unshift(empleado);
  Swal.fire({
      position: "center",
      icon: "success",
      title: "Los datos son exitosos",
      showConfirmButton: false,
      timer: 1500
    });
    }
  }

function search(){
  let searchEmpleado = document.getElementById("searchNS").value;
  searchEmpleado=Number.parseInt(searchEmpleado);
  let flag=false;
  let sueldo;
  for (let i = 0; i < empleados.length && !flag; i++) {
    if (searchEmpleado == Number.parseInt(empleados[i].isNS)) {
      sueldo = precioDia * empleados[i].isDias;
      Swal.fire({
        title: empleados[i].isNombre,
        text: "El sueldo de la persona "+ empleados[i].isNombre +" que trabajo "+ empleados[i].isDias+" dias"+  " es $" + sueldo,
        icon: "success"
      });
      flag = true;
    }
    else{
      Swal.fire({
        icon: "error",
        title: "Oops...",
        text: "El dato no se encontró",
      });
    }
  }

  if (!flag) {
    Swal.fire({
      icon: "error",
      title: "Oops...",
      text: "El dato no existe",
    });
  }

}

function look(){
  let buscar=document.getElementById("searchDias").value;
  let flag=false;
  let cadena ="";
  for (i=0; i<empleados.length && !flag; i++){
      if(buscar==empleados[i].isDias){
        cadena= cadena + " " + " "+empleados[i].isNombre+ ", ";
      }
  }
  if(buscar<=0){
    Swal.fire({
      icon: "error",
      title: "Oops...",
      text: "Ingrese positivos",
  });
  }
else if(cadena==""){
    Swal.fire({
    icon: "error",
    title: "El dato no se encontró",
    text: "....",
  });
}
else{
  Swal.fire({
    icon: "success",
    title: "Empleados con la misma cantidad de dias",
    text: cadena,
  });;
}
}